#ifndef UTILS_H
#define UTILS_H

#include <vector>
#include "clase.h"

std::vector<estudiante> ordenarBucketSort(std::vector<estudiante>);

#endif
